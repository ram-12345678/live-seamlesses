# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the license found in the
# MIT_LICENSE file in the root directory of this source tree.

from seamless_communication.cli.m4t.predict.predict import (
    add_inference_arguments as add_inference_arguments,
)
from seamless_communication.cli.m4t.predict.predict import (
    set_generation_opts as set_generation_opts,
)
